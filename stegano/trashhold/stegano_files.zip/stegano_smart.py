from typing import List, Tuple

BITS_IN_BYTE = 8
PIX_BYTE_LEN = BITS_IN_BYTE
LEN_PIX = 3


def int_to_bin(num: int, n: int = 0):
    return format(num, 'b').zfill(n)


def split_str_by_chunks(s: str, n: int):
    return [s[i: i + n] for i in range(0, len(s), n)]


def get_file_bin_by_chunks(file_name):
    pass


print(int_to_bin(37))
print(split_str_by_chunks("123456789" * 2, 2))
s = "123456789" * 2
print(s[:-1])


def change_num_ending(og_num: int, bin_str: str):
    num_str = int_to_bin(og_num, PIX_BYTE_LEN)
    num_str = num_str[: - len(bin_str)] + bin_str
    return num_str


def show_change(og_num: int, bin_str: str):
    print(int_to_bin(og_num, PIX_BYTE_LEN))
    print(change_num_ending(og_num, bin_str))


def pix_list_to_list(pix_list: List[Tuple[int]]) -> List[int]:
    list_total = []
    for pix in pix_list:
        list_total += list(pix)
    return list_total


def list_to_tup_list(lst: List[int], n: int = 1) -> List[Tuple[int]]:
    list_tup = [tuple(lst[i: i + n]) for i in range(0, len(lst), n)]
    if len(list_tup) > 0 and len(list_tup[-1]) < n:
        diff = n - len(list_tup[-1])
        list_tup[-1] += tuple([0] * diff)
    return list_tup

def list_to_pix_list(lst: List[int]) -> List[Tuple[int]]:
    return list_to_tup_list(lst, LEN_PIX)


pix_list = [(27, 64, 164), (248, 244, 194), (174, 246, 250), (149, 95, 232),
            (188, 156, 169), (71, 167, 127), (132, 173, 97), (113, 69, 206),
            (255, 29, 213), (53, 153, 220), (246, 225, 229), (142, 82, 175)]

print(pix_list_to_list(pix_list))
reg_list = pix_list_to_list(pix_list)
print(list_to_pix_list([]))

def bytes_from_file(filename):
    try:
        with open(filename, "rb") as f:
            # do while loop
            list_bytes = f.read()
    except:
        list_bytes = []

    return list_bytes

def byte_to_str_bin(byte):
    return int_to_bin(int(byte), BITS_IN_BYTE)

def file_to_bin_str(filename):
    list_bytes_int = bytes_from_file(filename)
    list_btye_str = [byte_to_str_bin(byte) for byte in list_bytes_int]
    return ''.join(list_btye_str)




list_bytes = bytes_from_file("try.exe")
print(list_bytes, f'\n{len(list_bytes)} {len(list_bytes) * 8}')

list_bytes = file_to_bin_str("try.exe")
print(list_bytes, f'\n{len(list_bytes)}')