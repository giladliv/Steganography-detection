# import moviepy
# from moviepy.editor import VideoFileClip
# import numpy as np
#
# clip = VideoFileClip('media/git.mp4').subclip(30,60)
# cols, rows = clip.size
# print(cols, rows)
# # n_frames = sum(1 for x in clip.iter_frames())
# print (clip.reader.nframes)
# print(len(clip.get_frame(2)))
# # me = np.array([[[0]*3]*cols]*rows)
# # for i in range(100):
# #     i = i * 1.0 / clip.fps
# #     clip.blit_on(np.array(me), i)
# clip.write_videofile("tryMe.mp4")
# # print(clip.get_frame(2)[0][0])
# # print(clip.fps * clip.duration)
# #
# # me = list(clip.get_frame(1))
# #
# # byte_arr = ''
# # count = 0
# # for row in me:
# #     for col in row:
# #         for i in col:
# #             if count == 20:
# #                 break
# #             byte_arr += '{:0>2x}'.format(i)
# #             count += 1
# #
# #
# # print(byte_arr)
# # # print(list(clip.iter_frames()))

import cv2
vidcap = cv2.VideoCapture('media/git.mp4')
success,image = vidcap.read()
count = 0
if success:
  cv2.imwrite("frame%d.jpg" % count, image)